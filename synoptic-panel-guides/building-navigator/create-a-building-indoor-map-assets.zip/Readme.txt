README – Sample Files for Synoptic Panel Tutorial

This archive contains sample material used in the Synoptic Panel how-to guide:

"Starting Canvas.pbix"

"3D Building" image

Floor plan SVGs

All content is provided by OKVIZ for demonstration and educational use with Synoptic Panel.

1. Sample data

All data in "Starting Canvas.pbix" is randomly generated.

Any resemblance to real properties, prices, addresses, companies, or people is coincidental.

These files are not intended to support real estate decisions, pricing, financial analysis, or any other real-world use.

Use the content only as sample data and example layouts.

2. No warranty and no support

Files are provided “as is” without warranties of any kind, express or implied.

OKVIZ does not guarantee correctness, completeness, or fitness for a particular purpose.

OKVIZ does not provide product support, consulting, or bug fixing for these sample files.

You use these files at your own risk.

3. Usage and redistribution

You may:

Use these files in personal, educational, or commercial projects.

Share or redistribute the .zip, in original or modified form.

Include screenshots and derived works in articles, videos, courses, or similar material.

When you use or redistribute the content, you must:

Attribute OKVIZ as the owner of the original sample files.

Example: Sample layout and images © OKVIZ – used with permission.

Keep any OKVIZ branding and copyright notices that appear in the files.

Make it clear that OKVIZ does not endorse your product, service, or training unless you have a separate written agreement with OKVIZ.

You may not:

Present the files as your own proprietary work without attribution.

Use the OKVIZ logo or brand in a way that suggests partnership or endorsement.

4. Third-party notices

Power BI and related names are trademarks of Microsoft Corporation.

Any AI or image tools referenced in the guide (for example, Gemini) are the property of their respective owners.

These tools and trademarks are mentioned only to explain how the sample content was created. No endorsement or affiliation is implied.

For more information about Synoptic Panel and other OKVIZ products, visit the OKVIZ website.